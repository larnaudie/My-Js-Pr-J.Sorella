module.exports = {
    qa: 'http://the-internet.herokuapp.com',
    dev: 'https://www.google.com/',
    staging: 'https://www.yahoo.com/'
}