module.exports = {
    userName: 'Julia',
    password: 'Password',
    validUserName: 'tomsmith',
    validPassword: 'SuperSecretPassword!'
}